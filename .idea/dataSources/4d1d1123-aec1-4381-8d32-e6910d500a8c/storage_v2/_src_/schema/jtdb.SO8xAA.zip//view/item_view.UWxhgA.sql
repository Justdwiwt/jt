create view item_view as (select `jtdb`.`tb_item`.`id`         AS `id`,
                                 `jtdb`.`tb_item`.`title`      AS `title`,
                                 `jtdb`.`tb_item`.`sell_point` AS `sell_point`,
                                 `jtdb`.`tb_item`.`num`        AS `num`,
                                 `jtdb`.`tb_item`.`barcode`    AS `barcode`,
                                 `jtdb`.`tb_item`.`image`      AS `image`,
                                 `jtdb`.`tb_item`.`cid`        AS `cid`,
                                 `jtdb`.`tb_item`.`status`     AS `status`
                          from `jtdb`.`tb_item`);

